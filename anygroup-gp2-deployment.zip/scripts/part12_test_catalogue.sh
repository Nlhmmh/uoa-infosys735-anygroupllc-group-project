#!/usr/bin/env bash
set -euo pipefail
exec python3 "$(dirname "$0")/part12_test_catalogue.py" "$@"
